# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a lightweight educational assistant based on the supplied project documentation. It provides:

- Q&A using Gemini
- Simple concept explanation using local **MBZUAI/LaMini-Flan-T5-783M**, with Gemini fallback
- 3-question MCQ quiz generation
- Simple text summarization
- Beginner → intermediate → advanced learning recommendations
- FastAPI backend
- Responsive HTML/CSS/JavaScript frontend

## Project structure

```text
EduGenie/
├── main.py
├── gemini_client.py
├── explanation_module.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
├── static/
│   └── style.css
└── tests/
    └── test_app.py
```

## 1. Prerequisites

Install:

- Python 3.11 or newer
- VS Code
- Internet access for the Gemini API
- A Gemini API key for Google AI Studio

The original project document uses Gemini 1.5 Pro. The implementation here uses the current Google Gen AI Python SDK and keeps the model configurable through `GEMINI_MODEL`.

## 2. Open in VS Code

Open the `EduGenie` folder in VS Code.

Open the VS Code terminal.

### Windows

```powershell
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 3. Configure Gemini

Copy `.env.example` to `.env`.

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

macOS/Linux:

```bash
cp .env.example .env
```

Open `.env` and replace:

```text
GEMINI_API_KEY=your_google_ai_studio_api_key_here
```

with your actual key.

Do not commit `.env` to Git.

## 4. Run the application

With the virtual environment activated:

```bash
uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

## 5. Test the application

Run:

```bash
pytest -q
```

You can also check:

```text
http://127.0.0.1:8000/health
```

Expected result:

```json
{"status":"ok","service":"EduGenie"}
```

## 6. API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/` | Web interface |
| GET | `/health` | Health check |
| POST | `/qna` | Question answering |
| POST | `/explain` | Topic explanation |
| POST | `/quiz` | Generate 3 MCQs |
| POST | `/summarize` | Summarize text |
| GET | `/learn/recommendations?topic=SQL` | Learning path |

### Example Q&A request

```bash
curl -X POST http://127.0.0.1:8000/qna \
  -H "Content-Type: application/json" \
  -d "{\"text\":\"Which is the largest ocean?\"}"
```

## 7. Explanation model

The supplied project documentation specifies:

```text
MBZUAI/LaMini-Flan-T5-783M
```

The code loads this model lazily, so starting the server does not immediately download the model.

The first explanation request may take longer because the model needs to be downloaded and loaded.

If your computer does not have enough resources for the local model, set:

```text
EXPLANATION_PROVIDER=gemini
```

in `.env`. Then the explanation module will use Gemini directly.

## 8. Troubleshooting

### "GEMINI_API_KEY is not configured"

Make sure `.env` exists in the project root and contains a valid key.

### Local explanation is slow

The LaMini model is much larger than the other parts of the application. Use:

```text
EXPLANATION_PROVIDER=gemini
```

to avoid local model loading.

### Quiz JSON error

The backend validates the Gemini response. Try the request again with a shorter, clearer passage.

### Port already in use

Use another port:

```bash
uvicorn main:app --reload --port 8001
```

Then open:

```text
http://127.0.0.1:8001
```

## Architecture

```text
User
  |
  v
HTML/CSS/JavaScript Frontend
  |
  v
FastAPI Backend
  |
  +--> /qna --------------------> Gemini
  |
  +--> /explain ----------------> LaMini-Flan-T5
  |                               |
  |                               +--> Gemini fallback
  |
  +--> /quiz -------------------> Gemini
  |
  +--> /summarize --------------> Gemini
  |
  +--> /learn/recommendations --> Gemini
  |
  v
Result displayed in browser
```

## Notes

The project is intentionally kept lightweight: there is no database, login system, or separate frontend build tool. This makes it easy to run as a student project in VS Code.
