# Source-based implementation notes

The supplied EduGenie project document describes:

1. A FastAPI backend.
2. Gemini for Q&A, summarization, quiz generation, and learning paths.
3. LaMini-Flan-T5 for concept explanations.
4. REST endpoints:
   - /qna
   - /explain
   - /quiz
   - /summarize
   - /learn/recommendations
5. A simple HTML/CSS frontend.
6. Local execution with Uvicorn.
7. Functional testing for questions, explanations, quizzes, summaries, and learning recommendations.

This implementation preserves that architecture while making two practical changes:

- Gemini access uses Google's current `google-genai` Python SDK rather than the older `google-generativeai` style shown in the document.
- The Gemini model name is configurable in `.env`, because model availability can change over time.

The original document names Gemini 1.5 Pro. The code therefore does not hard-code that retired/changed model name; it uses `GEMINI_MODEL`.

For explanation, the requested local LaMini-Flan-T5 model remains the default, with a Gemini fallback to make the application easier to run on modest computers.
